package com.example.camerawifiscanner

import android.Manifest
import android.content.pm.PackageManager
import android.net.wifi.WifiManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout

class MainActivity : AppCompatActivity() {
    private lateinit var previewView: PreviewView
    private lateinit var signalText: TextView
    private lateinit var hintText: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val wifiRefresh = object : Runnable {
        override fun run() {
            updateWifiSignal()
            handler.postDelayed(this, 2000)
        }
    }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        if (result[Manifest.permission.CAMERA] == true) startCamera()
        else Toast.makeText(this, "ক্যামেরা অনুমতি ছাড়া অ্যাপ চলবে না", Toast.LENGTH_LONG).show()
        updateWifiSignal()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
        val permissions = mutableListOf(Manifest.permission.CAMERA)
        if (android.os.Build.VERSION.SDK_INT >= 23) permissions.add(Manifest.permission.ACCESS_FINE_LOCATION)
        permissionLauncher.launch(permissions.toTypedArray())
    }

    private fun buildScreen() {
        val root = android.widget.FrameLayout(this)
        previewView = PreviewView(this).apply {
            layoutParams = android.widget.FrameLayout.LayoutParams(-1, -1)
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
        root.addView(previewView)

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 22, 28, 22)
            setBackgroundColor(Color.argb(205, 10, 22, 30))
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            text = "📶  LIVE Wi-Fi SCANNER"
            setTextColor(Color.WHITE); textSize = 18f
        }
        signalText = TextView(this).apply {
            text = "Wi-Fi সিগন্যাল মাপা হচ্ছে…"
            setTextColor(Color.WHITE); textSize = 28f
            setPadding(0, 10, 0, 4)
        }
        hintText = TextView(this).apply {
            text = "রুমে হাঁটুন এবং সিগন্যালের পরিবর্তন দেখুন"
            setTextColor(Color.LTGRAY); textSize = 14f
        }
        panel.addView(title)
        panel.addView(signalText)
        panel.addView(hintText)
        val params = android.widget.FrameLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP)
        params.setMargins(16, 24, 16, 0)
        root.addView(panel, params)
        setContentView(root)
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val provider = future.get()
                val preview = Preview.Builder().build().also {
                    it.setSurfaceProvider(previewView.surfaceProvider)
                }
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview)
            } catch (e: Exception) {
                Toast.makeText(this, "ক্যামেরা চালু করা যায়নি: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    @Suppress("DEPRECATION")
    private fun updateWifiSignal() {
        val wifi = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
        val info = try { wifi.connectionInfo } catch (_: SecurityException) { null }
        val rssi = info?.rssi ?: -127
        if (rssi <= -100 || info?.networkId == -1) {
            signalText.text = "Wi-Fi সংযুক্ত নয়"
            signalText.setTextColor(Color.WHITE)
            hintText.text = "Wi-Fi-তে সংযুক্ত হয়ে আবার দেখুন"
            return
        }
        // Common Android Wi-Fi RSSI scale; this is an estimate, not a calibrated percentage.
        val percent = ((rssi + 100) * 2).coerceIn(0, 100)
        val color = when {
            rssi >= -60 -> Color.rgb(80, 235, 125)
            rssi >= -75 -> Color.rgb(255, 205, 65)
            else -> Color.rgb(255, 90, 90)
        }
        signalText.text = "$rssi dBm   •   আনুমানিক $percent%"
        signalText.setTextColor(color)
        hintText.text = when {
            rssi >= -60 -> "সিগন্যাল ভালো"
            rssi >= -75 -> "সিগন্যাল মাঝারি"
            else -> "সিগন্যাল দুর্বল — রাউটারের কাছে যান"
        }
    }

    override fun onResume() {
        super.onResume()
        handler.post(wifiRefresh)
    }

    override fun onPause() {
        handler.removeCallbacks(wifiRefresh)
        super.onPause()
    }
}
