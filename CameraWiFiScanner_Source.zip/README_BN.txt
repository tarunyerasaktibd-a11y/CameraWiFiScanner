Camera WiFi Scanner — Android প্রজেক্ট

এই প্রজেক্টে ক্যামেরার লাইভ প্রিভিউয়ের ওপর Wi-Fi RSSI (dBm) এবং আনুমানিক শতাংশ দেখানো হয়।

গুরুত্বপূর্ণ:
- এটি Android Studio দিয়ে APK বানানোর SOURCE PROJECT; APK ফাইল নয়।
- ফোনে Android Studio নেই হলে সরাসরি ZIP খুললেই APK ইনস্টল হবে না।
- Camera permission দিন। Android-এর Location permission-ও চাইতে পারে, কারণ কিছু Android সংস্করণে Wi-Fi সংযোগের তথ্য পড়তে এটি দরকার হয়।
- Wi-Fi-তে সংযুক্ত থাকতে হবে।
- শতাংশটি আনুমানিক RSSI-ভিত্তিক সূচক; ইন্টারনেট স্পিড নয়।
- ক্যামেরা ছবি থেকে নিজে নিজে রুম শনাক্ত করে না; এটি শুধু ক্যামেরা ভিউয়ের ওপর বর্তমান ফোনের Wi-Fi সিগন্যাল দেখায়।

APK বানানোর সংক্ষিপ্ত ধাপ:
1. Android Studio-তে এই ফোল্ডারটি Open করুন।
2. Gradle sync শেষ হতে দিন।
3. Build > Build APK(s) নির্বাচন করুন।
4. app/build/outputs/apk/debug/app-debug.apk ফাইলটি ফোনে ইনস্টল করুন।

সম্ভাব্য সীমাবদ্ধতা:
Android-এর কিছু সংস্করণ/ফোনে Location permission, Wi-Fi সংযোগের অবস্থা বা নির্মাতার বিধিনিষেধের কারণে RSSI আপডেট সীমিত হতে পারে।
